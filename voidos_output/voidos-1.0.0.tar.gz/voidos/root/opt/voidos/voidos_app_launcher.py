#!/usr/bin/env python3
"""
voidOS App Launcher & Manager

Manages integrated app instances, lifecycle, and communication.
Provides unified access to all tools, dashboards, and utilities.
"""

import json
import logging
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable
from enum import Enum

logger = logging.getLogger(__name__)


class AppStatus(Enum):
    """App lifecycle states."""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    ERROR = "error"
    STOPPING = "stopping"


class App:
    """Base app definition."""
    
    def __init__(self, app_id: str, name: str, description: str, icon: str, 
                 command: Optional[str] = None, url: Optional[str] = None,
                 port: Optional[int] = None, tags: Optional[List[str]] = None):
        self.app_id = app_id
        self.name = name
        self.description = description
        self.icon = icon
        self.command = command  # Command to launch if local process
        self.url = url  # URL if external service
        self.port = port
        self.tags = tags or []
        self.status = AppStatus.STOPPED
        self.process: Optional[subprocess.Popen] = None
        self.created_at = datetime.utcnow().isoformat()
        self.started_at: Optional[str] = None
        self.metadata: Dict[str, Any] = {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize app to dict."""
        return {
            "app_id": self.app_id,
            "name": self.name,
            "description": self.description,
            "icon": self.icon,
            "status": self.status.value,
            "port": self.port,
            "url": self.url,
            "tags": self.tags,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "metadata": self.metadata
        }


class AppLauncher:
    """Manages app lifecycle and communication."""
    
    def __init__(self, apps_dir: Path = Path("/opt/voidos/apps")):
        self.apps_dir = apps_dir
        self.apps: Dict[str, App] = {}
        self.running_processes: Dict[str, subprocess.Popen] = {}
        self._initialize_builtin_apps()
    
    def _initialize_builtin_apps(self):
        """Initialize built-in voidOS apps."""
        
        # Terminal emulator
        self.register_app(App(
            app_id="terminal",
            name="Terminal",
            description="Command-line interface for system access",
            icon="⌨️",
            url="/apps/terminal",
            tags=["system", "utility"]
        ))
        
        # File manager
        self.register_app(App(
            app_id="files",
            name="File Manager",
            description="Navigate and manage files and directories",
            icon="📁",
            url="/apps/files",
            tags=["utility"]
        ))
        
        # Seed manager
        self.register_app(App(
            app_id="seed-manager",
            name="Seed Manager",
            description="Manage and verify blockchain seeds",
            icon="🌱",
            url="/apps/seed-manager",
            tags=["blockchain", "core"]
        ))
        
        # GhostShell interface
        self.register_app(App(
            app_id="ghostshell",
            name="GhostShell",
            description="AI agent execution environment",
            icon="👻",
            url="/apps/ghostshell",
            tags=["ai", "agent"]
        ))
        
        # LLM Training interface
        self.register_app(App(
            app_id="llm-training",
            name="LLM Training",
            description="Machine learning model training interface",
            icon="🤖",
            url="/apps/llm-training",
            tags=["ml", "training"]
        ))
        
        # Memory Loop monitor
        self.register_app(App(
            app_id="memory-loop",
            name="Memory Loop",
            description="Monitor and manage system memory cycles",
            icon="🔄",
            url="/apps/memory-loop",
            tags=["system", "monitoring"]
        ))
        
        # Logs viewer
        self.register_app(App(
            app_id="logs",
            name="Logs Viewer",
            description="View and analyze system logs",
            icon="📋",
            url="/apps/logs",
            tags=["utility", "monitoring"]
        ))
        
        # Settings
        self.register_app(App(
            app_id="settings",
            name="Settings",
            description="Configure voidOS system settings",
            icon="⚙️",
            url="/apps/settings",
            tags=["system", "configuration"]
        ))
    
    def register_app(self, app: App):
        """Register an app."""
        self.apps[app.app_id] = app
        logger.info(f"Registered app: {app.app_id}")
    
    def get_app(self, app_id: str) -> Optional[App]:
        """Get app by ID."""
        return self.apps.get(app_id)
    
    def list_apps(self, tag: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all apps, optionally filtered by tag."""
        apps = list(self.apps.values())
        if tag:
            apps = [a for a in apps if tag in a.tags]
        return [a.to_dict() for a in apps]
    
    def launch_app(self, app_id: str) -> bool:
        """Launch an app."""
        app = self.get_app(app_id)
        if not app:
            logger.error(f"App not found: {app_id}")
            return False
        
        if app.status == AppStatus.RUNNING:
            logger.info(f"App already running: {app_id}")
            return True
        
        app.status = AppStatus.STARTING
        
        try:
            if app.command:
                # Launch local process
                process = subprocess.Popen(
                    app.command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                self.running_processes[app_id] = process
                app.process = process
                app.status = AppStatus.RUNNING
                app.started_at = datetime.utcnow().isoformat()
                logger.info(f"Launched app: {app_id} (PID: {process.pid})")
                return True
            else:
                # URL-based app (served by dashboard)
                app.status = AppStatus.RUNNING
                app.started_at = datetime.utcnow().isoformat()
                logger.info(f"App registered as service: {app_id}")
                return True
        except Exception as e:
            logger.error(f"Failed to launch app {app_id}: {e}")
            app.status = AppStatus.ERROR
            app.metadata["error"] = str(e)
            return False
    
    def stop_app(self, app_id: str) -> bool:
        """Stop a running app."""
        app = self.get_app(app_id)
        if not app:
            return False
        
        if app.status != AppStatus.RUNNING:
            return True
        
        app.status = AppStatus.STOPPING
        
        try:
            if app_id in self.running_processes:
                process = self.running_processes[app_id]
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                del self.running_processes[app_id]
            
            app.status = AppStatus.STOPPED
            logger.info(f"Stopped app: {app_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to stop app {app_id}: {e}")
            app.status = AppStatus.ERROR
            return False
    
    def get_app_status(self, app_id: str) -> Optional[Dict[str, Any]]:
        """Get app status."""
        app = self.get_app(app_id)
        return app.to_dict() if app else None
    
    def get_all_status(self) -> List[Dict[str, Any]]:
        """Get status of all apps."""
        return [app.to_dict() for app in self.apps.values()]
    
    def restart_app(self, app_id: str) -> bool:
        """Restart an app."""
        if not self.stop_app(app_id):
            return False
        time.sleep(1)
        return self.launch_app(app_id)


class TerminalApp:
    """Terminal emulator service for web dashboard."""
    
    def __init__(self, shell: str = "/bin/bash", history_size: int = 1000):
        self.shell = shell
        self.history: List[Dict[str, Any]] = []
        self.history_size = history_size
        self.process: Optional[subprocess.Popen] = None
        self.cwd = Path.home()
    
    def execute_command(self, command: str) -> Dict[str, Any]:
        """Execute a shell command and return output."""
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=str(self.cwd),
                capture_output=True,
                text=True,
                timeout=30
            )
            
            output = {
                "command": command,
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "timestamp": datetime.utcnow().isoformat(),
                "cwd": str(self.cwd)
            }
            
            # Add to history
            self.history.append(output)
            if len(self.history) > self.history_size:
                self.history.pop(0)
            
            return output
        except subprocess.TimeoutExpired:
            return {
                "command": command,
                "exit_code": -1,
                "stderr": "Command timeout (30s limit)",
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "command": command,
                "exit_code": -1,
                "stderr": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    def change_directory(self, path: str) -> Dict[str, Any]:
        """Change current working directory."""
        try:
            new_path = Path(path).expanduser()
            if not new_path.exists():
                return {"error": f"Path not found: {path}"}
            if not new_path.is_dir():
                return {"error": f"Not a directory: {path}"}
            
            self.cwd = new_path
            return {"cwd": str(self.cwd), "success": True}
        except Exception as e:
            return {"error": str(e)}
    
    def get_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get command history."""
        return self.history[-limit:]
    
    def clear_history(self):
        """Clear history."""
        self.history.clear()


# Global instances
app_launcher: Optional[AppLauncher] = None
terminal_app: Optional[TerminalApp] = None


def initialize_apps():
    """Initialize app system."""
    global app_launcher, terminal_app
    
    app_launcher = AppLauncher()
    terminal_app = TerminalApp()
    
    logger.info("App launcher initialized")
    return app_launcher, terminal_app


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    launcher, terminal = initialize_apps()
    
    print("Available Apps:")
    for app in launcher.list_apps():
        print(f"  - {app['name']} ({app['app_id']})")

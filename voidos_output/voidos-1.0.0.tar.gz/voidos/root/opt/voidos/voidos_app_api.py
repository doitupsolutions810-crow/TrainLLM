#!/usr/bin/env python3
"""
Enhanced voidOS Bootstrap with App Launcher Integration

Adds REST API endpoints for app management, terminal execution, and tool integration.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import urlparse, parse_qs

logger = logging.getLogger(__name__)


class AppAPIExtension:
    """REST API extension for app launcher and terminal management."""
    
    def __init__(self, app_launcher=None, terminal_app=None):
        self.app_launcher = app_launcher
        self.terminal_app = terminal_app
    
    def handle_request(self, path: str, method: str, body: Optional[str] = None) -> tuple:
        """
        Handle API requests.
        Returns (status_code, response_data, content_type)
        """
        
        # Parse path
        parsed = urlparse(path)
        path_parts = [p for p in parsed.path.split('/') if p]
        query_params = parse_qs(parsed.query) if parsed.query else {}
        
        # App endpoints
        if len(path_parts) >= 2 and path_parts[0] == 'api' and path_parts[1] == 'apps':
            
            if len(path_parts) == 3 and path_parts[2] == 'list' and method == 'GET':
                return self._handle_list_apps(query_params)
            
            elif len(path_parts) == 4 and path_parts[2] == 'launch' and method == 'POST':
                app_id = path_parts[3]
                return self._handle_launch_app(app_id)
            
            elif len(path_parts) == 4 and path_parts[2] == 'stop' and method == 'POST':
                app_id = path_parts[3]
                return self._handle_stop_app(app_id)
            
            elif len(path_parts) == 4 and path_parts[2] == 'status' and method == 'GET':
                app_id = path_parts[3]
                return self._handle_app_status(app_id)
            
            elif len(path_parts) == 3 and path_parts[2] == 'status' and method == 'GET':
                return self._handle_all_status()
        
        # Terminal endpoints
        elif len(path_parts) >= 2 and path_parts[0] == 'api' and path_parts[1] == 'terminal':
            
            if len(path_parts) == 3 and path_parts[2] == 'execute' and method == 'POST':
                return self._handle_terminal_execute(body)
            
            elif len(path_parts) == 3 and path_parts[2] == 'history' and method == 'GET':
                limit = int(query_params.get('limit', ['50'])[0])
                return self._handle_terminal_history(limit)
            
            elif len(path_parts) == 3 and path_parts[2] == 'clear' and method == 'POST':
                return self._handle_terminal_clear()
            
            elif len(path_parts) == 3 and path_parts[2] == 'pwd' and method == 'GET':
                return self._handle_terminal_pwd()
        
        return (404, {'error': 'Not Found'}, 'application/json')
    
    def _handle_list_apps(self, query_params: Dict) -> tuple:
        """List available apps."""
        if not self.app_launcher:
            return (503, {'error': 'App launcher not available'}, 'application/json')
        
        tag = query_params.get('tag', [None])[0]
        apps = self.app_launcher.list_apps(tag=tag)
        return (200, apps, 'application/json')
    
    def _handle_launch_app(self, app_id: str) -> tuple:
        """Launch an app."""
        if not self.app_launcher:
            return (503, {'error': 'App launcher not available'}, 'application/json')
        
        success = self.app_launcher.launch_app(app_id)
        status = self.app_launcher.get_app_status(app_id)
        
        return (200 if success else 500, {
            'success': success,
            'app_id': app_id,
            'status': status
        }, 'application/json')
    
    def _handle_stop_app(self, app_id: str) -> tuple:
        """Stop a running app."""
        if not self.app_launcher:
            return (503, {'error': 'App launcher not available'}, 'application/json')
        
        success = self.app_launcher.stop_app(app_id)
        status = self.app_launcher.get_app_status(app_id)
        
        return (200 if success else 500, {
            'success': success,
            'app_id': app_id,
            'status': status
        }, 'application/json')
    
    def _handle_app_status(self, app_id: str) -> tuple:
        """Get app status."""
        if not self.app_launcher:
            return (503, {'error': 'App launcher not available'}, 'application/json')
        
        status = self.app_launcher.get_app_status(app_id)
        if not status:
            return (404, {'error': f'App not found: {app_id}'}, 'application/json')
        
        return (200, status, 'application/json')
    
    def _handle_all_status(self) -> tuple:
        """Get status of all apps."""
        if not self.app_launcher:
            return (503, {'error': 'App launcher not available'}, 'application/json')
        
        status = self.app_launcher.get_all_status()
        return (200, status, 'application/json')
    
    def _handle_terminal_execute(self, body: Optional[str]) -> tuple:
        """Execute terminal command."""
        if not self.terminal_app:
            return (503, {'error': 'Terminal not available'}, 'application/json')
        
        if not body:
            return (400, {'error': 'Missing command'}, 'application/json')
        
        try:
            data = json.loads(body)
            command = data.get('command', '')
            
            if not command:
                return (400, {'error': 'Empty command'}, 'application/json')
            
            result = self.terminal_app.execute_command(command)
            return (200, result, 'application/json')
        except Exception as e:
            return (400, {'error': str(e)}, 'application/json')
    
    def _handle_terminal_history(self, limit: int) -> tuple:
        """Get terminal history."""
        if not self.terminal_app:
            return (503, {'error': 'Terminal not available'}, 'application/json')
        
        history = self.terminal_app.get_history(limit)
        return (200, {'history': history}, 'application/json')
    
    def _handle_terminal_clear(self) -> tuple:
        """Clear terminal history."""
        if not self.terminal_app:
            return (503, {'error': 'Terminal not available'}, 'application/json')
        
        self.terminal_app.clear_history()
        return (200, {'success': True}, 'application/json')
    
    def _handle_terminal_pwd(self) -> tuple:
        """Get current working directory."""
        if not self.terminal_app:
            return (503, {'error': 'Terminal not available'}, 'application/json')
        
        return (200, {'cwd': str(self.terminal_app.cwd)}, 'application/json')


# Monkey-patch to extend existing DashboardAPIHandler
def extend_dashboard_api_handler(handler_class, app_launcher, terminal_app):
    """Extend DashboardAPIHandler with app API endpoints."""
    
    original_do_get = handler_class.do_GET
    original_do_post = handler_class.do_POST if hasattr(handler_class, 'do_POST') else None
    
    api_extension = AppAPIExtension(app_launcher, terminal_app)
    
    def new_do_get(self):
        """Enhanced GET handler."""
        if '/api/apps/' in self.path or '/api/terminal/' in self.path:
            status_code, response, content_type = api_extension.handle_request(
                self.path, 'GET'
            )
            self._serve_json_response(status_code, response, content_type)
        else:
            original_do_get(self)
    
    def new_do_post(self):
        """Enhanced POST handler."""
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else None
        
        if '/api/apps/' in self.path or '/api/terminal/' in self.path:
            status_code, response, content_type = api_extension.handle_request(
                self.path, 'POST', body
            )
            self._serve_json_response(status_code, response, content_type)
        elif original_do_post:
            original_do_post(self)
        else:
            self.send_error(405, "Method Not Allowed")
    
    def _serve_json_response(self, status_code, response, content_type):
        """Serve JSON response."""
        if isinstance(response, (dict, list)):
            response_text = json.dumps(response, indent=2)
        else:
            response_text = str(response)
        
        self.send_response(status_code)
        self.send_header('Content-type', content_type)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers()
        self.wfile.write(response_text.encode())
    
    handler_class.do_GET = new_do_get
    handler_class.do_POST = new_do_post
    handler_class._serve_json_response = _serve_json_response


if __name__ == '__main__':
    print("App API Extension loaded successfully")
